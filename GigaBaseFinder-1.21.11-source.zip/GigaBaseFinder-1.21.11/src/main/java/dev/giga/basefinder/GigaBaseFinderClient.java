package dev.giga.basefinder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.core.BlockPos;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class GigaBaseFinderClient implements ClientModInitializer {
    private static final Minecraft MC = Minecraft.getInstance();
    private static final List<FoundBlock> FOUND = new ArrayList<>();
    private static KeyMapping openMenu;
    private static boolean finderEnabled = true;
    private static boolean includeBarrels = true;
    private static boolean includeShulkers = true;
    private static int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.giga_base_finder.open",
                GLFW.GLFW_KEY_B,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new FinderScreen());
                } else if (client.screen instanceof FinderScreen) {
                    client.setScreen(null);
                }
            }

            if (finderEnabled && ++tickCounter >= 40) {
                tickCounter = 0;
                scanNearbyContainers();
            }
        });
    }

    static List<FoundBlock> getFound() {
        return List.copyOf(FOUND);
    }

    static boolean isFinderEnabled() {
        return finderEnabled;
    }

    static void toggleFinder() {
        finderEnabled = !finderEnabled;
        if (!finderEnabled) FOUND.clear();
        else scanNearbyContainers();
    }

    static void toggleBarrels() { includeBarrels = !includeBarrels; }
    static void toggleShulkers() { includeShulkers = !includeShulkers; }
    static boolean barrelsEnabled() { return includeBarrels; }
    static boolean shulkersEnabled() { return includeShulkers; }

    private static void scanNearbyContainers() {
        if (MC.level == null || MC.player == null) return;

        BlockPos origin = MC.player.blockPosition();
        int radius = 24;
        List<FoundBlock> results = new ArrayList<>();

        for (int x = -radius; x <= radius; x++) {
            for (int y = -16; y <= 16; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = origin.offset(x, y, z);
                    if (!MC.level.isLoaded(pos)) continue;
                    Block block = MC.level.getBlockState(pos).getBlock();

                    boolean chest = block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST;
                    boolean barrel = block == Blocks.BARREL && includeBarrels;
                    boolean shulker = isShulker(block) && includeShulkers;

                    if (chest || barrel || shulker) {
                        double distance = MC.player.distanceToSqr(
                                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                        results.add(new FoundBlock(pos.immutable(), label(block), distance));
                    }
                }
            }
        }

        results.sort(Comparator.comparingDouble(FoundBlock::distanceSquared));
        FOUND.clear();
        FOUND.addAll(results);
    }

    private static boolean isShulker(Block block) {
        return block == Blocks.SHULKER_BOX
                || block == Blocks.WHITE_SHULKER_BOX
                || block == Blocks.ORANGE_SHULKER_BOX
                || block == Blocks.MAGENTA_SHULKER_BOX
                || block == Blocks.LIGHT_BLUE_SHULKER_BOX
                || block == Blocks.YELLOW_SHULKER_BOX
                || block == Blocks.LIME_SHULKER_BOX
                || block == Blocks.PINK_SHULKER_BOX
                || block == Blocks.GRAY_SHULKER_BOX
                || block == Blocks.LIGHT_GRAY_SHULKER_BOX
                || block == Blocks.CYAN_SHULKER_BOX
                || block == Blocks.PURPLE_SHULKER_BOX
                || block == Blocks.BLUE_SHULKER_BOX
                || block == Blocks.BROWN_SHULKER_BOX
                || block == Blocks.GREEN_SHULKER_BOX
                || block == Blocks.RED_SHULKER_BOX
                || block == Blocks.BLACK_SHULKER_BOX;
    }

    private static String label(Block block) {
        if (block == Blocks.CHEST) return "Chest";
        if (block == Blocks.TRAPPED_CHEST) return "Trapped Chest";
        if (block == Blocks.BARREL) return "Barrel";
        return "Shulker Box";
    }

    record FoundBlock(BlockPos pos, String type, double distanceSquared) {
        double distance() { return Math.sqrt(distanceSquared); }
    }
}
