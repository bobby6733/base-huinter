package dev.giga.basefinder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class FinderScreen extends Screen {
    private int scroll;

    public FinderScreen() {
        super(Component.literal("Giga Base Finder"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 105;
        int top = this.height / 2 - 92;

        addRenderableWidget(Button.builder(
                Component.literal("Finder: " + (GigaBaseFinderClient.isFinderEnabled() ? "ON" : "OFF")),
                button -> {
                    GigaBaseFinderClient.toggleFinder();
                    button.setMessage(Component.literal("Finder: " +
                            (GigaBaseFinderClient.isFinderEnabled() ? "ON" : "OFF")));
                }).bounds(left, top, 210, 20).build());

        addRenderableWidget(Button.builder(
                Component.literal("Barrels: " + (GigaBaseFinderClient.barrelsEnabled() ? "ON" : "OFF")),
                button -> {
                    GigaBaseFinderClient.toggleBarrels();
                    button.setMessage(Component.literal("Barrels: " +
                            (GigaBaseFinderClient.barrelsEnabled() ? "ON" : "OFF")));
                }).bounds(left, top + 25, 102, 20).build());

        addRenderableWidget(Button.builder(
                Component.literal("Shulkers: " + (GigaBaseFinderClient.shulkersEnabled() ? "ON" : "OFF")),
                button -> {
                    GigaBaseFinderClient.toggleShulkers();
                    button.setMessage(Component.literal("Shulkers: " +
                            (GigaBaseFinderClient.shulkersEnabled() ? "ON" : "OFF")));
                }).bounds(left + 108, top + 25, 102, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Close"),
                button -> onClose()).bounds(left, top + 53, 210, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        super.render(graphics, mouseX, mouseY, delta);

        int left = this.width / 2 - 105;
        int top = this.height / 2 - 30;
        graphics.drawCenteredString(this.font, "Nearby container candidates",
                this.width / 2, top - 12, 0xFFFFFF);

        List<GigaBaseFinderClient.FoundBlock> found = GigaBaseFinderClient.getFound();
        if (found.isEmpty()) {
            graphics.drawCenteredString(this.font, "No containers found in the scan radius.",
                    this.width / 2, top + 8, 0xAAAAAA);
        } else {
            int visible = Math.min(6, found.size());
            for (int i = 0; i < visible; i++) {
                var item = found.get(i);
                String line = String.format("%s  %d %d %d  %.1fm",
                        item.type(), item.pos().getX(), item.pos().getY(),
                        item.pos().getZ(), item.distance());
                graphics.drawString(this.font, line, left, top + 8 + i * 12, 0xE6E6E6);
            }
            if (found.size() > visible) {
                graphics.drawString(this.font, "+" + (found.size() - visible) + " more",
                        left, top + 8 + visible * 12, 0xAAAAAA);
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
