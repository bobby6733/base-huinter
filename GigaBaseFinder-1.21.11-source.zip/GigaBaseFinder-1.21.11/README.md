# Giga Base Finder — Minecraft Java 1.21.11

A client-side Fabric project with a **B-key GUI** and a nearby-container candidate scanner.

## Included
- Press **B** to open/close the menu.
- Toggle the scanner, barrels, and shulker boxes.
- Scans loaded blocks within 24 blocks horizontally and 16 vertically.
- Lists nearby chests, trapped chests, barrels, and shulker boxes with coordinates and distance.

## Important limitation
This starter project is a **container locator**, not a full through-wall ESP renderer or an automatic player-base detector. Containers can occur in ordinary builds, so results are only candidates. It does not reveal unloaded chunks or server-hidden data.

## Build
Requirements: Java 21 and Gradle 8.12 or newer.

From this folder, run:

### Windows
```bat
gradle build
```

### macOS / Linux
```bash
gradle build
```

The remapped mod JAR should be created in `build/libs/` (use the JAR without `-dev` in its filename).

## Install
1. Install Fabric Loader for Minecraft **1.21.11**.
2. Put the built JAR in your `.minecraft/mods` folder.
3. Launch the Fabric 1.21.11 profile.

Fabric API is a required dependency and must also be in the `mods` folder.

## Versions
- Minecraft: 1.21.11
- Java: 21+
- Fabric Loader: 0.18.1
- Fabric API: 0.141.1+1.21.11
- Fabric Loom: 1.14.10

This ZIP contains source code and build files; it is not a precompiled `.jar`.
